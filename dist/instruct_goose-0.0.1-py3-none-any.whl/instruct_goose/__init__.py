__version__ = "0.0.1"

from instruct_goose.agent import Agent
from instruct_goose.reward import RewardModel
from instruct_goose.trainer import RLHFTrainer
from instruct_goose.utils import create_reference_model, RLHFConfig